package com.example.workoutapp;

public interface OnClickListener {
    void onItemClick (int position);
}
