package com.example.workoutapp;

public class ExercisesList {
    private String exerciseName, exerciseDescription;

    public String getExerciseName() {
        return exerciseName;
    }

    public String getExerciseDescription() {
        return exerciseDescription;
    }
}
